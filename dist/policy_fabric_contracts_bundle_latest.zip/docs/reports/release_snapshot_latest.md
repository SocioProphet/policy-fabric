# Release Snapshot

- generatedAt: 2026-03-31T19:17:05Z
- repoCommitBeforeSnapshot: 71277787583435bbb85f78d9c397cd15af4d94b1
- repoCommitShort: 7127778
- bundlePath: dist/policy_fabric_contracts_bundle_latest.zip
- repoSnapshotPath: /mnt/data/policy_fabric_repo_snapshot_latest.zip
- notes: Corrected the AgentPlane research source to SocioProphet/agentplane, added a Policy Fabric release-pack contract and example, extended doctor validation, and rebuilt the latest distributable bundle.
