# Branch Audit Report

Overall status: WARN

Current branch: `main`
Local branches: `4`
Remotes: `0`
Merge commits in history: `1`

- [OK] branch:head-attached — PFB010_BRANCH_HEAD_OK — HEAD is attached to `main`
- [OK] branch:merge-state — PFB012_BRANCH_STATE_OK — No in-progress merge/rebase/cherry-pick/revert state detected
- [OK] branch:main-present — PFB014_BRANCH_MAIN_PRESENT — `main` branch exists
- [OK] branch:single-main-only — PFB017_BRANCH_TOPOLOGY_OK — Local branches present: ['docs/github-publish-pairing-prep', 'main', 'work/official-agentplane-init-eval', 'work/policy-semantics-overlap']
- [WARN] branch:remotes — PFB019_BRANCH_NO_REMOTE — No remotes configured in snapshot; remote protection cannot be observed here
- [OK] branch:merge-history — PFB021_BRANCH_MERGE_HISTORY_PRESENT — History contains 1 merge commits
- [OK] branch:baseline-tags — PFB022_BRANCH_BASELINE_TAGS_OK — Baseline tags present: ['baseline/2026-04-02_pre-branch-audit', 'baseline/2026-04-04_branch-audited', 'baseline/2026-04-05_docs-github-prep-validated', 'baseline/2026-04-05_post-github-publish-prep', 'baseline/2026-04-05_pre-github-publish-prep']
- [OK] branch:policy-protected-main — PFB024_BRANCH_POLICY_OK — Branch policy protects `main` as the baseline branch

## Recommended Next Work Branches

- `work/official-agentplane-init-eval` — Run the first real official AgentPlane initialization in a disposable clone or feature branch.
- `work/policy-semantics-overlap` — Deepen selector-overlap analysis and richer failure-fixture semantics without risking the main workflow surfaces.
